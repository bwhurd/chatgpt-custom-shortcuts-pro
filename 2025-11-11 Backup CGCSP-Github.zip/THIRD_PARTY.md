# Third-Party Libraries

This project includes the following JavaScript libraries from [GSAP (GreenSock Animation Platform)](https://gsap.com), by Jack Doyle:

- `gsap.min.js`
- `Flip.min.js`
- `Observer.min.js`
- `ScrollToPlugin.min.js`

**Version:** 3.13.0  
**License:** [GreenSock Standard License](https://gsap.com/standard-license)