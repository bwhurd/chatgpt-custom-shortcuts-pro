// build-sync.js
const fs = require('fs');
const { compileStandalone } = require('webext-options-sync/dist/bundle-utils');

const code = compileStandalone(); // returns full UMD/standalone build
fs.writeFileSync('lib/webext-options-sync.js', code);

console.log('✅ webext-options-sync.js standalone build created in /lib');
