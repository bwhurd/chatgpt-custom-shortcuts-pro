# Run with: powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\bwhur\Dropbox\CGCSP-Github\moveAndRenameNumberedLanguageFiles.ps1"

# -------- Config --------
$archiveRoot = 'C:\Users\bwhur\Dropbox\CGCSP-git-scrap\old-language-files'
$localesRoot = 'C:\Users\bwhur\Dropbox\CGCSP-Github\_locales'
$locales     = @('en','es','hi','ja','ru','uk')
# ------------------------

# --- helpers (file-path enumeration only) ---
function Resolve-CGCSPUniqueFilePath {
    param([Parameter(Mandatory=$true)][string]$BasePath)

    if (-not (Test-Path -LiteralPath $BasePath)) { return $BasePath }

    $dir  = Split-Path -LiteralPath $BasePath -Parent
    $leaf = Split-Path -LiteralPath $BasePath -Leaf
    $stem = [System.IO.Path]::GetFileNameWithoutExtension($leaf)
    $ext  = [System.IO.Path]::GetExtension($leaf)

    $i = 1
    do {
        $candidate = Join-Path $dir ("{0}_{1:00}{2}" -f $stem, $i, $ext)
        $i++
    } while (Test-Path -LiteralPath $candidate)
    return $candidate
}

function Get-HighestUpdatedFile {
    <# Accepts: messagesupdated01.json and messages_updated_01.json #>
    param([Parameter(Mandatory=$true)][System.IO.FileInfo[]]$Files)
    $pattern = '^messages_?updated_?(\d+)\.json$'
    $candidates = foreach ($f in $Files) {
        $m = [regex]::Match($f.Name, $pattern, 'IgnoreCase')
        if ($m.Success) { [pscustomobject]@{ File = $f; Num = [int]$m.Groups[1].Value } }
    }
    if (-not $candidates) { return $null }
    return ($candidates | Sort-Object Num -Descending | Select-Object -First 1).File
}
# --- /helpers ---

# 1) Create date-stamped archive folder, enumerated if today's exists
$today = Get-Date -Format 'yyyy-MM-dd'
$archiveDateDir = Join-Path $archiveRoot $today

if (Test-Path -LiteralPath $archiveDateDir) {
    $i = 1
    do {
        $candidate = Join-Path $archiveRoot ("{0}_{1:00}" -f $today, $i)
        $i++
    } while (Test-Path -LiteralPath $candidate)
    $archiveDateDir = $candidate
}

New-Item -ItemType Directory -Path $archiveDateDir -Force | Out-Null
foreach ($loc in $locales) {
    New-Item -ItemType Directory -Path (Join-Path $archiveDateDir $loc) -Force | Out-Null
}

Write-Host "Archive destination: $archiveDateDir"

# 2–8) Process each locale
foreach ($loc in $locales) {
    $srcDir = Join-Path $localesRoot $loc
    $dstDir = Join-Path $archiveDateDir $loc

    if (-not (Test-Path -LiteralPath $srcDir)) {
        Write-Warning "[$loc] Source folder not found: $srcDir. Skipping."
        continue
    }

    $files = Get-ChildItem -LiteralPath $srcDir -File -Filter '*.json' | Sort-Object Name
    if ($files.Count -le 1) {
        Write-Host "[$loc] $($files.Count) JSON file found. Skipping."
        continue
    }

    $highest = Get-HighestUpdatedFile -Files $files
    if (-not $highest) {
        Write-Warning "[$loc] Multiple JSONs but none match 'messagesupdated##.json' (underscore optional). Skipping."
        continue
    }

    Write-Host "[$loc] Highest file: $($highest.Name)"

    # Move all except the highest to the correct archive subfolder
    foreach ($f in $files | Where-Object { $_.FullName -ne $highest.FullName }) {
        $destPath = Resolve-CGCSPUniqueFilePath -BasePath (Join-Path $dstDir $f.Name)
        Move-Item -LiteralPath $f.FullName -Destination $destPath -Force
        Write-Host "[$loc] Moved: $($f.Name)  ->  $destPath"
    }

    # Ensure no conflict with an existing messages.json
    $targetPath = Join-Path $srcDir 'messages.json'
    if (Test-Path -LiteralPath $targetPath) {
        $archiveTarget = Resolve-CGCSPUniqueFilePath -BasePath (Join-Path $dstDir 'messages.json')
        Move-Item -LiteralPath $targetPath -Destination $archiveTarget -Force
        Write-Host "[$loc] Existing messages.json moved to archive: $archiveTarget"
    }

    # Rename highest to messages.json in-place (same locale)
    Rename-Item -LiteralPath $highest.FullName -NewName 'messages.json' -Force
    Write-Host "[$loc] Renamed: $($highest.Name)  ->  messages.json"
}

Write-Host "Done."
