#!/usr/bin/env python3
# moveNewEntriesInMessagesJsonToEnd.py
# Place list of entries to move in messagesJsonToMoveToEnd.txt (one per line).
# Copy to run in powershell: py "C:\Users\bwhur\Dropbox\CGCSP-Github\moveNewEntriesInMessagesJsonToEnd.py"
# Moves specified keys to the end of messages.json files (for multiple locales),
# preserving original order for all other keys. Outputs to messages_updated_XX.json
# in the same directory as each input file, without modifying originals.

import os
import json
import re
from collections import OrderedDict


def read_keys_file(keys_file_path):
    # Read keys from text file (one per line), ignoring blanks and comments.
    # Deduplicate while preserving order.
    keys = []
    seen = set()
    if not os.path.isfile(keys_file_path):
        raise FileNotFoundError(f"Keys file not found: {keys_file_path}")
    # utf-8-sig handles BOM if present
    with open(keys_file_path, "r", encoding="utf-8-sig") as f:
        for line in f:
            key = line.strip()
            if not key or key.startswith("#"):
                continue
            if key not in seen:
                seen.add(key)
                keys.append(key)
    return keys


def load_ordered_json(path):
    # Load JSON preserving key order; tolerate UTF-8 BOM with utf-8-sig
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Input JSON not found: {path}")
    with open(path, "r", encoding="utf-8-sig") as f:
        data = json.load(f, object_pairs_hook=OrderedDict)
    if not isinstance(data, dict):
        raise ValueError(f"Top-level JSON is not an object in: {path}")
    return data


def next_output_path(
    out_dir, base_name="messages_updated", start_index=1, width=2, max_index=9999
):
    # Find the next available output file name with incrementing index.
    for i in range(start_index, max_index + 1):
        candidate = os.path.join(out_dir, f"{base_name}_{i:0{width}d}.json")
        if not os.path.exists(candidate):
            return candidate
    raise RuntimeError(
        f"Could not find available filename in {out_dir} for {base_name}_XX.json"
    )


def move_keys_to_end(data_odict, keys_to_move):
    # Build new ordered dict: keep original order for non-moved keys,
    # then append moved keys in the order provided (if they exist).
    new_odict = OrderedDict()
    move_set = set(keys_to_move)
    for k, v in data_odict.items():
        if k not in move_set:
            new_odict[k] = v
    for k in keys_to_move:
        if k in data_odict:
            new_odict[k] = data_odict[k]
    return new_odict


def dump_json_with_tabs(ordered_obj):
    # Dump JSON with pretty indentation and no trailing commas.
    # Then convert leading spaces on each line to tabs (1 tab per indent level).
    json_str = json.dumps(
        ordered_obj, ensure_ascii=False, indent=1, separators=(",", ": ")
    )
    json_str = re.sub(r"(?m)^( +)", lambda m: "\t" * len(m.group(1)), json_str)
    return json_str


def process_file(input_path, keys_to_move):
    in_dir = os.path.dirname(input_path)
    data = load_ordered_json(input_path)

    # Reorder
    new_data = move_keys_to_end(data, keys_to_move)

    # Determine output path
    out_path = next_output_path(
        in_dir, base_name="messages_updated", start_index=1, width=2
    )

    # Serialize with consistent formatting
    json_str = dump_json_with_tabs(new_data)

    # Write output (no extra blank lines)
    with open(out_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(json_str)

    return out_path


def main():
    base_dir = os.path.abspath(os.path.dirname(__file__))
    keys_file = os.path.join(base_dir, "messagesJsonToMoveToEnd.txt")

    # Locales to process
    locales = ["en", "es", "hi", "ja", "ru", "uk"]

    # Build list of input files
    input_files = [
        os.path.join(base_dir, "_locales", loc, "messages.json") for loc in locales
    ]

    # Read keys to move (preserving order, ignoring blanks)
    try:
        keys_to_move = read_keys_file(keys_file)
    except Exception as e:
        print(f"ERROR: {e}")
        return

    # Process each file
    for in_path in input_files:
        try:
            print(f"Input File:  {in_path}")
            out_path = process_file(in_path, keys_to_move)
            print(f"Output File: {out_path}")
        except FileNotFoundError:
            print(f"SKIPPED (not found): {in_path}")
        except json.JSONDecodeError as e:
            print(f"ERROR parsing JSON in {in_path}: {e}")
        except Exception as e:
            print(f"ERROR processing {in_path}: {e}")


if __name__ == "__main__":
    main()
