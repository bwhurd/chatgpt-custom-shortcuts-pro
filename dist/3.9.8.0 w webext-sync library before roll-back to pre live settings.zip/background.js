/**
 * MV3 service worker for ChatGPT Custom Shortcuts Pro
 * - Loads webext-options-sync + shared options-storage
 * - Ensures defaults/migrations run
 * - Broadcasts live option changes to popup and all tabs
 * - Minimal message API to get/set options
 */

// Load the OptionsSync library and shared options definition (non-module SW)
importScripts('lib/webext-options-sync.js', 'options-storage.js');

// Ensure options are initialized as the SW starts
(async () => {
	try {
		await optionsStorage.getAll();
		console.info('[ChatGPT Shortcuts] Options initialized');
	} catch (e) {
		console.warn('[ChatGPT Shortcuts] Options initialization failed', e);
	}
})();

// Utility: broadcast to runtime (popup) and all tabs (content scripts)
function broadcast(type, payload = {}) {
	try {
		// Popup / any runtime listeners
		chrome.runtime.sendMessage({ type, ...payload }, () => {
			// Accessing lastError silences unchecked errors without throwing
			// e.g., when no listener is present
			// eslint-disable-next-line no-unused-expressions
			chrome.runtime.lastError;
		});
	} catch {
		// Intentionally ignore
	}

	// All tabs (content scripts)
	chrome.tabs.query({}, (tabs) => {
		for (const tab of tabs) {
			if (tab.id != null) {
				chrome.tabs.sendMessage(tab.id, { type, ...payload }, () => {
					// eslint-disable-next-line no-unused-expressions
					chrome.runtime.lastError;
				});
			}
		}
	});
}

// Live change notifications: OptionsSync -> popup + content
optionsStorage.onChanged((newOptions, oldOptions) => {
	broadcast('options:changed', { newOptions, oldOptions });
});

// Small message API for any context
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
	if (!msg || typeof msg !== 'object') return;

	// Get all options
	if (msg.type === 'options:getAll') {
		optionsStorage
			.getAll()
			.then((options) => sendResponse({ ok: true, options }))
			.catch((error) => sendResponse({ ok: false, error: String(error) }));
		return true; // async
	}

	// Merge-set some options
	if (msg.type === 'options:set') {
		const patch = msg?.options ?? {};
		optionsStorage
			.set(patch)
			.then(() => sendResponse({ ok: true }))
			.catch((error) => sendResponse({ ok: false, error: String(error) }));
		return true; // async
	}

	// Replace all options
	if (msg.type === 'options:setAll') {
		const next = msg?.options ?? {};
		optionsStorage
			.setAll(next)
			.then(() => sendResponse({ ok: true }))
			.catch((error) => sendResponse({ ok: false, error: String(error) }));
		return true; // async
	}
});
