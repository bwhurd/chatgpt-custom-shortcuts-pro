/* auth.js (global, non-module) */
(() => {
  const PROFILE_KEY = 'csp_auth_profile_v1';
  const TOKEN_KEY = 'csp_auth_token_v1';
  // Minimal OAuth scope for Drive backup only
  const REQUIRED_SCOPES = ['https://www.googleapis.com/auth/drive.appdata'];

  const setLocal = (k, v) => chrome.storage.local.set({ [k]: v });
  const setSession = async (t) =>
    t ? chrome.storage.session.set({ [TOKEN_KEY]: t }) : chrome.storage.session.remove(TOKEN_KEY);

  const getSessionToken = async () =>
    (await chrome.storage.session.get(TOKEN_KEY))[TOKEN_KEY] || '';

  // Use the Chrome Extension OAuth client via identity.getAuthToken
  const getAuthTokenChrome = (interactive) =>
    new Promise((resolve) => {
      chrome.identity.getAuthToken({ interactive, scopes: REQUIRED_SCOPES }, (token) => {
        if (chrome.runtime.lastError) return resolve('');
        resolve(token || '');
      });
    });

  async function getAuthToken({ interactive = false } = {}) {
    const cached = await getSessionToken();
    if (cached) return cached;
    const token = await getAuthTokenChrome(interactive);
    if (token) await setSession(token);
    return token;
  }

  const removeCached = (token) =>
    new Promise((resolve) => {
      if (!token) return resolve();
      chrome.identity.removeCachedAuthToken({ token }, () => resolve());
    });

  async function fetchProfile() {
    // Prefer lightweight chrome.identity email if user granted it; otherwise store minimal
    try {
      const hasEmail = await new Promise((resolve) =>
        chrome.permissions.contains({ permissions: ['identity.email'] }, resolve),
      );
      if (hasEmail && chrome.identity.getProfileUserInfo) {
        const info = await new Promise((resolve) =>
          chrome.identity.getProfileUserInfo((i) => resolve(i || {})),
        );
        const profile = { email: info.email || '', name: '', sub: info.id || '' };
        await setLocal(PROFILE_KEY, profile);
        return profile;
      }
    } catch (_) {}
    const profile = { email: '', name: '', sub: '' };
    await setLocal(PROFILE_KEY, profile);
    return profile;
  }

  async function getSavedAuth() {
    // Treat "linked" as "we have a session token we set during login".
    const token = await getSessionToken();
    if (!token) {
      await setLocal(PROFILE_KEY, null);
      return { profile: null };
    }
    const o = await chrome.storage.local.get(PROFILE_KEY);
    return { profile: o[PROFILE_KEY] || null };
  }

  async function googleLogin() {
    // Best effort to avoid silent reuse: drop cached token so Chrome may prompt
    try {
      const existing = await getSessionToken();
      if (existing) {
        await new Promise((resolve) =>
          chrome.identity.removeCachedAuthToken({ token: existing }, resolve),
        );
        await setSession('');
      }
    } catch (_) {}

    const token = await getAuthToken({ interactive: true }); // Chrome-managed flow
    if (!token) throw new Error(chrome.runtime.lastError?.message || 'LOGIN_FAILED');
    await setSession(token);

    // Store lightweight profile (uses identity.email if the user granted it)
    const profile = await fetchProfile();
    return { profile };
  }

  async function googleLogout() {
    const token = await getSessionToken();
    try {
      if (token) {
        try {
          await removeCached(token);
        } catch (_) {}
      }
      // Hard reset of Identity API state so future non-interactive calls won't succeed.
      try {
        await chrome.identity.clearAllCachedAuthTokens();
      } catch (_) {}
    } finally {
      await setSession('');
      await setLocal(PROFILE_KEY, null);
      try {
        await window.CloudStorage?._clearKnownFileId?.();
      } catch (_) {}
    }
  }

  window.CloudAuth = { getSavedAuth, googleLogin, googleLogout, getAuthToken };
})();
