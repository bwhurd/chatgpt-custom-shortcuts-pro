(function () {
  // Minimal shared schema for wiring/maintenance.
  // Keep this file dependency-free so it can be loaded early.
  window.CSP_SETTINGS_SCHEMA = window.CSP_SETTINGS_SCHEMA || {};

  window.CSP_SETTINGS_SCHEMA.excludeDefaultsKeys = [
    // Keep current behavior: popup should not seed these on first run.
    'modelNames',
    'hideArrowButtonsCheckbox',
    'hideCornerButtonsCheckbox',
  ];

  window.CSP_SETTINGS_SCHEMA.popup = {
    // Inputs that have specialized behavior and should NOT use the generic data-sync checkbox/radio handler.
    excludedStateWiringKeys: [
      'useAltForModelSwitcherRadio',
      'useControlForModelSwitcherRadio',
      'fadeSlimSidebarEnabled',
      'moveTopBarToBottomCheckbox',
    ],

    // Opt-in selectors for generic wiring / discovery.
    stateInputSelector: 'input[type="checkbox"][data-sync], input[type="radio"][data-sync]',
    shortcutInputSelector: 'input.key-input',
  };
})();

