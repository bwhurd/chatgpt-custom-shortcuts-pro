(() => {
  // Temporary release kill switch.
  // Set to 0 to keep Lazy Fast Mode completely inert for shipped builds.
  const ENABLE_LAZY_FAST_MODE = 0;
  globalThis.__CSP_ENABLE_LAZY_FAST_MODE = ENABLE_LAZY_FAST_MODE === 1;
  if (!globalThis.__CSP_ENABLE_LAZY_FAST_MODE) return;

  const SCRIPT_ID = 'csp-lazy-fast-bridge';
  const config = Object.freeze({
    retainedTurnCount: 24,
    minTurnCountToTrim: 40,
    logPrefix: '[CSP Lazy Fast Mode]',
  });

  const injectBridge = () => {
    if (document.getElementById(SCRIPT_ID)) return;

    const script = document.createElement('script');
    script.id = SCRIPT_ID;
    script.src = chrome.runtime.getURL('lazy-fast-bridge.js');
    script.dataset.retainedTurnCount = String(config.retainedTurnCount);
    script.dataset.minTurnCountToTrim = String(config.minTurnCountToTrim);
    script.dataset.logPrefix = config.logPrefix;
    script.async = false;
    (document.documentElement || document.head).appendChild(script);
  };

  if (document.documentElement) {
    injectBridge();
  } else {
    document.addEventListener('DOMContentLoaded', injectBridge, { once: true });
  }
})();
