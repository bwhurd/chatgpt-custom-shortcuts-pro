(() => {
  if (window.__cspLazyFastBridgeInstalled) return;
  window.__cspLazyFastBridgeInstalled = true;

  const currentScript = document.currentScript;
  const RETAINED_TURN_COUNT = Math.max(
    24,
    Number(currentScript?.dataset?.retainedTurnCount) || 24,
  );
  const MIN_TURN_COUNT_TO_TRIM = Math.max(
    RETAINED_TURN_COUNT + 2,
    Number(currentScript?.dataset?.minTurnCountToTrim) || 40,
  );
  const LOG_PREFIX = String(currentScript?.dataset?.logPrefix || '[CSP Lazy Fast Mode]');
  const ROUTE_RE = /^\/c\/([^/?#]+)/;
  const CONVERSATION_PATH_RE = /^\/backend-api\/conversation\/([^/?#]+)$/i;
  const HISTORY_DATA_NODE_ID = 'csp-lazy-fast-history-data';
  const HISTORY_MESSAGE_SOURCE = 'csp-lazy-fast-history';
  const BYPASS_KEY = 'csp_lazy_fast_skip_once';
  const RETAINED_COUNT_KEY_PREFIX = 'csp_lazy_fast_retained_turn_count:';
  const ANCHOR_KEY_PREFIX = 'csp_lazy_fast_restore_anchor:';

  const getConversationIdFromPath = (pathname = location.pathname || '') =>
    pathname.match(ROUTE_RE)?.[1] || '';

  const toAbsoluteUrl = (value) => {
    if (!value) return '';
    try {
      return new URL(value, location.origin).href;
    } catch {
      return '';
    }
  };

  const cloneNode = (node) => {
    if (!node || typeof node !== 'object') return node;
    return {
      ...node,
      children: Array.isArray(node.children) ? [...node.children] : [],
    };
  };

  const normalizeText = (value) => {
    if (typeof value !== 'string') return '';
    return value.replace(/\r\n?/g, '\n').trim();
  };

  const getRetainedCountKey = (conversationId) =>
    `${RETAINED_COUNT_KEY_PREFIX}${String(conversationId || '')}`;

  const getAnchorKey = (conversationId) =>
    `${ANCHOR_KEY_PREFIX}${String(conversationId || '')}`;

  const readRequestedRetainedTurnCount = (conversationId) => {
    try {
      const raw = sessionStorage.getItem(getRetainedCountKey(conversationId));
      const parsed = Number(raw);
      if (!Number.isFinite(parsed)) return RETAINED_TURN_COUNT;
      return Math.max(RETAINED_TURN_COUNT, Math.floor(parsed));
    } catch {
      return RETAINED_TURN_COUNT;
    }
  };

  const formatSegmentLabel = (value) => {
    const normalized = String(value || '')
      .trim()
      .replace(/[_-]+/g, ' ')
      .replace(/\s+/g, ' ')
      .toLowerCase();
    if (!normalized) return 'Rich content';

    const aliases = {
      'image asset pointer': 'Image',
      image: 'Image',
      audio: 'Audio',
      file: 'File',
      attachment: 'Attachment',
      document: 'Document',
      'shared document': 'Shared document',
      artifact: 'Artifact',
      canvas: 'Canvas',
      table: 'Table',
      citation: 'Citation',
      quote: 'Quote',
      tool: 'Tool output',
      'execution output': 'Execution output',
      output: 'Execution output',
    };

    if (aliases[normalized]) return aliases[normalized];
    return normalized.replace(/\b\w/g, (char) => char.toUpperCase());
  };

  const buildRichSummary = (value) => {
    if (!value || typeof value !== 'object') return '';

    const bits = [];
    const push = (candidate) => {
      const text = normalizeText(candidate);
      if (!text || bits.includes(text)) return;
      bits.push(text);
    };

    push(value.title);
    push(value.name);
    push(value.display_name);
    push(value.file_name);
    push(value.filename);
    push(value.mime_type);
    push(value.url);
    if (typeof value.asset_pointer === 'string') push('asset pointer');
    if (typeof value.size_bytes === 'number' && Number.isFinite(value.size_bytes)) {
      push(`${Math.max(1, Math.round(value.size_bytes / 1024))} KB`);
    }
    push(value.status);

    if (!bits.length) {
      const keys = Object.keys(value).filter(Boolean).slice(0, 4);
      if (keys.length) push(`Fields: ${keys.join(', ')}`);
    }

    return bits.join(' • ').slice(0, 240);
  };

  const createRichSegment = (kind, source, fallbackSummary = '') => {
    const richType = normalizeText(kind) || 'rich_content';
    const summary = normalizeText(fallbackSummary) || buildRichSummary(source);
    return {
      type: 'rich',
      richType,
      label: formatSegmentLabel(richType),
      summary,
    };
  };

  const extractSegmentsFromParts = (parts, fallbackType = '') => {
    if (!Array.isArray(parts) || !parts.length) return [];

    const segments = [];
    for (const part of parts) {
      if (typeof part === 'string') {
        const text = normalizeText(part);
        if (text) segments.push({ type: 'text', text });
        continue;
      }

      if (!part || typeof part !== 'object') continue;

      const partType = String(part.content_type || part.type || fallbackType || '').trim();
      if (partType === 'code') {
        const text = normalizeText(part.text || '');
        if (text) {
          segments.push({
            type: 'code',
            text,
            language: typeof part.language === 'string' ? part.language.trim() : '',
          });
          continue;
        }
      }

      if (partType === 'execution_output') {
        const text = normalizeText(part.text || '');
        if (text) {
          segments.push({ type: 'output', text });
          continue;
        }
      }

      const text = normalizeText(part.text || part.caption || part.alt || part.summary || '');
      if (text && (!partType || partType === 'text' || partType === 'paragraph')) {
        segments.push({ type: 'text', text });
        continue;
      }

      segments.push(createRichSegment(partType || fallbackType, part, text));
    }

    return segments;
  };

  const extractSegments = (message) => {
    const content = message?.content || {};
    const contentType = content.content_type || '';

    if (contentType === 'text') {
      const segments = extractSegmentsFromParts(content.parts, 'text');
      if (segments.length) return segments;

      const text = normalizeText(content.text || '');
      return text ? [{ type: 'text', text }] : [];
    }

    if (contentType === 'multimodal_text') {
      const segments = extractSegmentsFromParts(content.parts, 'multimodal_text');
      if (segments.length) return segments;

      const text = normalizeText(content.text || '');
      return text ? [{ type: 'text', text }] : [createRichSegment(contentType, content)];
    }

    if (contentType === 'code') {
      const text = normalizeText(content.text || '');
      return text
        ? [{
            type: 'code',
            text,
            language: typeof content.language === 'string' ? content.language.trim() : '',
          }]
        : [];
    }

    if (contentType === 'execution_output') {
      const text = normalizeText(content.text || '');
      return text ? [{ type: 'output', text }] : [];
    }

    return [createRichSegment(contentType, content)];
  };

  const getRenderableRole = (node) => {
    const message = node?.message;
    if (!message || message.metadata?.is_visually_hidden_from_conversation) return '';

    const role = message.author?.role;
    if (role !== 'user' && role !== 'assistant') return '';

    return extractSegments(message).length ? role : '';
  };

  const getActiveBranchNodeIds = (mapping, currentNodeId) => {
    const branch = [];
    const visited = new Set();
    let nodeId = currentNodeId;

    while (nodeId && mapping?.[nodeId] && !visited.has(nodeId)) {
      visited.add(nodeId);
      branch.push(nodeId);
      nodeId = mapping[nodeId].parent || '';
    }

    branch.reverse();
    return branch;
  };

  const buildBranchHistory = (payload) => {
    if (!payload?.mapping || !payload?.current_node) return null;

    const branchNodeIds = getActiveBranchNodeIds(payload.mapping, payload.current_node);
    if (!branchNodeIds.length) return null;

    const turns = [];
    let currentTurn = null;

    const segmentCounts = {};

    const appendSegment = (role, nodeId, segment) => {
      if (!segment || (segment.type !== 'rich' && !segment.text)) return;
      segmentCounts[segment.type] = (segmentCounts[segment.type] || 0) + 1;

      if (!currentTurn || currentTurn.role !== role) {
        currentTurn = {
          id: nodeId,
          role,
          startNodeId: nodeId,
          nodeIds: [nodeId],
          segments: [segment],
        };
        turns.push(currentTurn);
        return;
      }

      currentTurn.nodeIds.push(nodeId);
      const lastSegment = currentTurn.segments[currentTurn.segments.length - 1];
      if (
        lastSegment &&
        lastSegment.type === segment.type &&
        segment.type !== 'rich' &&
        (lastSegment.language || '') === (segment.language || '')
      ) {
        const separator = segment.type === 'text' ? '\n\n' : '\n';
        lastSegment.text = `${lastSegment.text}${separator}${segment.text}`.trim();
        return;
      }

      currentTurn.segments.push(segment);
    };

    for (const nodeId of branchNodeIds) {
      const node = payload.mapping[nodeId];
      const role = getRenderableRole(node);
      if (!role) continue;

      const segments = extractSegments(node.message);
      if (!segments.length) continue;
      for (const segment of segments) appendSegment(role, nodeId, segment);
    }

    return {
      branchNodeIds,
      turns,
      segmentCounts,
    };
  };

  const buildSyntheticRoot = (rootId, firstChildId) => ({
    id: rootId,
    message: null,
    parent: null,
    children: firstChildId ? [firstChildId] : [],
  });

  const pruneConversationPayload = (payload, responseUrl) => {
    const branchHistory = buildBranchHistory(payload);
    if (!branchHistory) return null;

    const { branchNodeIds, turns, segmentCounts } = branchHistory;
    if (branchNodeIds.length < 2 || turns.length < MIN_TURN_COUNT_TO_TRIM) return null;

    const conversationId = payload.conversation_id || '';
    const requestedRetainedTurnCount = readRequestedRetainedTurnCount(conversationId);

    let keepTurnIndex = Math.max(0, turns.length - requestedRetainedTurnCount);
    if (turns[keepTurnIndex]?.role === 'assistant' && keepTurnIndex > 0) {
      keepTurnIndex -= 1;
    }

    const keepStartNodeId = turns[keepTurnIndex]?.startNodeId;
    const keepStartIndex = branchNodeIds.indexOf(keepStartNodeId);
    if (keepStartIndex <= 0) return null;

    const keptBranchNodeIds = branchNodeIds.slice(keepStartIndex);
    if (keptBranchNodeIds.length >= branchNodeIds.length) return null;

    const keptNodeIdSet = new Set(keptBranchNodeIds);
    const syntheticRootId = `csp-lazy-fast-root-${payload.current_node}`;
    const nextMapping = {
      [syntheticRootId]: buildSyntheticRoot(syntheticRootId, keptBranchNodeIds[0] || ''),
    };

    for (const nodeId of keptBranchNodeIds) {
      const sourceNode = payload.mapping[nodeId];
      if (!sourceNode) continue;

      const nextNode = cloneNode(sourceNode);
      nextNode.parent =
        nodeId === keptBranchNodeIds[0]
          ? syntheticRootId
          : keptNodeIdSet.has(sourceNode.parent)
            ? sourceNode.parent
            : syntheticRootId;
      nextNode.children = Array.isArray(sourceNode.children)
        ? sourceNode.children.filter((childId) => keptNodeIdSet.has(childId))
        : [];
      nextMapping[nodeId] = nextNode;
    }

    const nextPayload = {
      ...payload,
      mapping: nextMapping,
    };

    const historyData = {
      conversationId: payload.conversation_id || '',
      title: typeof payload.title === 'string' ? payload.title : '',
      keptStartIndex: keepTurnIndex,
      requestedRetainedTurnCount,
      totalTurnCount: turns.length,
      turns: turns.map((turn) => ({
        id: turn.id,
        role: turn.role,
        startNodeId: turn.startNodeId,
        nodeIds: [...turn.nodeIds],
        segments: turn.segments.map((segment) => ({ ...segment })),
      })),
      segmentCounts: { ...segmentCounts },
    };

    const stats = {
      url: responseUrl,
      conversationId: payload.conversation_id || '',
      totalTurns: turns.length,
      keptTurns: turns.length - keepTurnIndex,
      totalBranchNodes: branchNodeIds.length,
      keptBranchNodes: keptBranchNodeIds.length + 1,
      keptStartIndex: keepTurnIndex,
      currentNode: payload.current_node,
      requestedRetainedTurnCount,
      segmentCounts: { ...segmentCounts },
    };

    return {
      payload: nextPayload,
      historyData,
      stats,
    };
  };

  const shouldAttemptPrune = (requestUrl, response) => {
    if (!response?.ok) return false;
    if ((response.headers.get('content-type') || '').toLowerCase().indexOf('application/json') === -1) {
      return false;
    }

    const conversationIdOnPage = getConversationIdFromPath();
    const absoluteUrl = toAbsoluteUrl(response.url || requestUrl);
    if (!absoluteUrl) return false;

    let parsedUrl;
    try {
      parsedUrl = new URL(absoluteUrl);
    } catch {
      return false;
    }

    const match = parsedUrl.pathname.match(CONVERSATION_PATH_RE);
    if (!match) return false;

    if (!conversationIdOnPage) return true;
    return conversationIdOnPage === match[1];
  };

  const buildRewrittenResponse = (response, payloadText) => {
    const headers = new Headers(response.headers);
    headers.delete('content-length');
    headers.delete('content-encoding');
    headers.set('content-type', 'application/json; charset=utf-8');

    const rewritten = new Response(payloadText, {
      status: response.status,
      statusText: response.statusText,
      headers,
    });

    try {
      Object.defineProperty(rewritten, 'url', {
        value: response.url,
        configurable: true,
      });
    } catch { }

    return rewritten;
  };

  const publishHistoryData = (historyData, stats) => {
    let node = document.getElementById(HISTORY_DATA_NODE_ID);
    if (!(node instanceof HTMLScriptElement)) {
      node = document.createElement('script');
      node.id = HISTORY_DATA_NODE_ID;
      node.type = 'application/json';
      (document.documentElement || document.head).appendChild(node);
    }

    const serialized = JSON.stringify({
      ...historyData,
      stats,
    });
    node.textContent = serialized;

    window.__cspLazyFastLastHistory = historyData;
    window.__cspLazyFastLastPrune = stats;
    window.postMessage(
      {
        source: HISTORY_MESSAGE_SOURCE,
        payload: {
          ...historyData,
          stats,
        },
      },
      location.origin,
    );
  };

  const shouldBypassTrimOnce = () => {
    try {
      if (localStorage.getItem(BYPASS_KEY) !== 'true') return false;
      localStorage.removeItem(BYPASS_KEY);
      return true;
    } catch {
      return false;
    }
  };

  const originalFetch = window.fetch;
  if (typeof originalFetch !== 'function') return;

  window.fetch = async function (...args) {
    const [input] = args;
    const requestUrl =
      typeof input === 'string'
        ? input
        : input instanceof Request
          ? input.url
          : typeof input?.url === 'string'
            ? input.url
            : '';

    const response = await originalFetch.apply(this, args);
    if (!shouldAttemptPrune(requestUrl, response)) return response;
    if (shouldBypassTrimOnce()) {
      console.info(`${LOG_PREFIX} bypassing trim for one reload.`);
      return response;
    }

    try {
      const payload = await response.clone().json();
      const result = pruneConversationPayload(payload, response.url || requestUrl);
      if (!result?.payload || !result.historyData) return response;

      publishHistoryData(result.historyData, result.stats);

      const payloadText = JSON.stringify(result.payload);
      console.info(
        `${LOG_PREFIX} kept ${result.stats.keptTurns}/${result.stats.totalTurns} turns and ${result.stats.keptBranchNodes}/${result.stats.totalBranchNodes} branch nodes for ${result.stats.conversationId || 'conversation'}.`,
        result.stats,
      );
      window.dispatchEvent(
        new CustomEvent('csp:lazy-fast-pruned', {
          detail: result.stats,
        }),
      );
      return buildRewrittenResponse(response, payloadText);
    } catch (error) {
      console.warn(`${LOG_PREFIX} prune skipped after error.`, error);
      return response;
    }
  };

  console.info(`${LOG_PREFIX} bridge installed.`);
})();
