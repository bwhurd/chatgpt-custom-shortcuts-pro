(function initModelPickerSelectors(root, factory) {
  const selectors = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = selectors;
  }
  root.CSPModelPickerSelectors = selectors;
})(typeof globalThis !== 'undefined' ? globalThis : this, () => {
  const LEGACY_MODEL_MENU_BUTTON_SELECTOR = 'button[data-testid="model-switcher-dropdown-button"]';
  const LEGACY_MODEL_MENU_BUTTON_CASE_SELECTOR =
    'button[data-testid="Model-switCher-dropdown-button"]';
  const COMPOSER_MODEL_MENU_BUTTON_SELECTOR =
    '[data-composer-surface="true"] button.__composer-pill[aria-haspopup="menu"][id^="radix-"]';
  const MODEL_MENU_BUTTON_SELECTORS = Object.freeze([
    LEGACY_MODEL_MENU_BUTTON_SELECTOR,
    LEGACY_MODEL_MENU_BUTTON_CASE_SELECTOR,
    COMPOSER_MODEL_MENU_BUTTON_SELECTOR,
  ]);
  const MODEL_MENU_BUTTON_SELECTOR = MODEL_MENU_BUTTON_SELECTORS.join(', ');
  const MODEL_MENU_SELECTOR = '[data-radix-menu-content][data-state="open"][role="menu"]';
  const COMPOSER_INTELLIGENCE_MENU_CONTENT_SELECTOR =
    '[data-testid="composer-intelligence-picker-content"]';
  const MODEL_SUBMENU_TRIGGER_SELECTOR =
    '[role="menuitem"][aria-haspopup="menu"], [role="menuitem"][data-has-submenu]';
  const MODEL_CONFIGURE_MENU_ITEM_SELECTOR = '[data-testid="model-configure-modal"]';
  const MODEL_CONFIGURE_DIALOG_SELECTOR = '[role="dialog"]';
  const MODEL_SELECTION_LABEL_ID = 'model-selection-label';
  const THINKING_EFFORT_SELECTION_LABEL_ID = 'thinking-effort-selection-label';
  const MODEL_THINKING_EFFORT_ROW_SELECTOR = '[data-model-picker-thinking-effort-row="true"]';
  const MODEL_THINKING_EFFORT_MENU_ITEM_SELECTOR =
    '[data-model-picker-thinking-effort-menu-item="true"]';
  const MODEL_THINKING_EFFORT_ACTION_SELECTOR =
    '[data-model-picker-thinking-effort-action="true"][aria-haspopup="menu"]';
  const MODEL_THINKING_EFFORT_OPTION_SELECTOR = '[role="group"] > [role="menuitemradio"]';
  const PILL_ADVANCED_TOGGLE_SELECTOR =
    '[role="menuitem"][aria-expanded]:not([aria-haspopup="menu"])';
  const PILL_RESET_MENU_ITEM_SELECTOR = '[role="menuitem"][class*="_ResetToDefault"]';
  const CHAT_WORK_SURFACE_GROUP_SELECTORS = Object.freeze([
    'header [role="radiogroup"]',
    'header [role="group"]',
  ]);
  const CHAT_WORK_SURFACE_GROUP_SELECTOR = CHAT_WORK_SURFACE_GROUP_SELECTORS.join(', ');
  const CHAT_WORK_SURFACE_RADIO_SELECTOR = 'button[role="radio"][aria-checked]';

  function normalizePillMenuLabel(value) {
    return String(value || '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function isLikelyPillModelLabel(value) {
    const text = normalizePillMenuLabel(value);
    return /^(?:gpt[-\s]*)?\d+(?:\.\d+)?(?:\b|$)/i.test(text) || /^o\d+(?:\b|$)/i.test(text);
  }

  function classifyPillSubmenuLabels(labels) {
    const normalized = (Array.isArray(labels) ? labels : [])
      .map(normalizePillMenuLabel)
      .filter(Boolean);
    if (normalized.length >= 2 && normalized.every(isLikelyPillModelLabel)) return 'model';
    if (normalized.length === 2) return 'speed';
    if (normalized.length >= 3) return 'effort';
    return '';
  }

  function isPillAdvancedToggle(element) {
    return (
      !!element &&
      element.getAttribute?.('role') === 'menuitem' &&
      element.hasAttribute?.('aria-expanded') === true &&
      element.getAttribute?.('aria-haspopup') !== 'menu'
    );
  }

  function isPillAdvancedToggleExpanded(element) {
    return isPillAdvancedToggle(element) && element.getAttribute('aria-expanded') === 'true';
  }

  // The current integrated picker keeps its model list in the same Radix menu
  // and exposes the view switch as a structural menuitem rather than the old
  // aria-haspopup submenu trigger. Keep this attribute-based so it survives
  // hashed class/name changes and localized visible text.
  function isModelSelectionViewTrigger(element) {
    if (
      !element ||
      element.getAttribute?.('role') !== 'menuitem' ||
      !element.closest?.('[data-model-selection-view="true"]')
    ) {
      return false;
    }

    // Chat currently marks the view toggle interactive and exposes
    // aria-expanded. Work uses the same structural row but marks it
    // data-interactive="false" and omits aria-expanded. In both cases the
    // row is the only view-control menuitem with a data-interactive state and
    // no separate aria label/ submenu ownership; Power, speed, reset, and
    // effort controls carry their own structural markers or labels.
    const interactiveState = element.getAttribute?.('data-interactive');
    if (interactiveState !== 'true' && interactiveState !== 'false') return false;
    if (element.hasAttribute?.('aria-haspopup')) return false;
    // Chat exposes a localized/accessibility label together with
    // aria-expanded; Work's non-interactive row has no label. Other labelled
    // controls (for example Power) do not carry data-interactive.
    if (interactiveState === 'false' && element.hasAttribute?.('aria-label')) return false;
    if (interactiveState === 'true' && !element.hasAttribute?.('aria-expanded')) return false;
    return true;
  }

  function unique(values) {
    return [...new Set((values || []).filter(Boolean))];
  }

  function getChatWorkSurfaceToggleSelectors() {
    return CHAT_WORK_SURFACE_GROUP_SELECTORS.map(
      (groupSelector) => `${groupSelector} ${CHAT_WORK_SURFACE_RADIO_SELECTOR}`,
    );
  }

  function getChatWorkSurfaceToggleMatchGroups() {
    return [
      ['role="radiogroup"', 'role="radio"', 'aria-checked='],
      ['role="group"', 'role="radio"', 'aria-checked='],
    ];
  }

  function getModelSwitcherButtonMatchGroups() {
    return [
      ['data-testid="model-switcher-dropdown-button"'],
      ['data-testid="Model-switCher-dropdown-button"'],
      ['__composer-pill', 'aria-haspopup="menu"', 'id="radix-'],
    ];
  }

  function getModelSwitcherMenuMatchGroups() {
    return [
      ['data-radix-menu-content', 'role="menu"', 'data-state="open"'],
      ['data-testid="composer-intelligence-picker-content"'],
      ['role="menu"', 'data-testid="model-configure-modal"'],
    ];
  }

  function getConfigureDialogMatchGroups() {
    return [
      ['role="dialog"', `id="${MODEL_SELECTION_LABEL_ID}"`],
      ['role="dialog"', `id="${THINKING_EFFORT_SELECTION_LABEL_ID}"`],
    ];
  }

  function getConfigureModelComboboxMatchGroups() {
    return [[`id="${MODEL_SELECTION_LABEL_ID}"`, 'role="combobox"', 'aria-controls=']];
  }

  function getConfigureModelListboxMatchGroups() {
    return [['role="listbox"', 'role="option"']];
  }

  function getThinkingEffortComboboxMatchGroups() {
    return [[`id="${THINKING_EFFORT_SELECTION_LABEL_ID}"`, 'role="combobox"', 'aria-controls=']];
  }

  function getThinkingEffortListboxMatchGroups() {
    return [['role="listbox"', 'role="option"']];
  }

  function getModelThinkingEffortActionMatchGroups() {
    return [
      [
        'data-model-picker-thinking-effort-action="true"',
        'aria-haspopup="menu"',
        'role="menuitem"',
      ],
    ];
  }

  function getModelThinkingEffortMenuMatchGroups() {
    return [['role="menu"', 'role="menuitemradio"', 'Standard', 'Extended']];
  }

  function getModelThinkingEffortStandardMatchGroups() {
    return [['role="menuitemradio"', 'Standard']];
  }

  function getModelThinkingEffortExtendedMatchGroups() {
    return [['role="menuitemradio"', 'Extended']];
  }

  function isUsablyVisibleElement(element, windowObj = root) {
    const ElementCtor = windowObj?.Element || root.Element;
    if (!ElementCtor || !(element instanceof ElementCtor) || !element.isConnected) return false;
    try {
      const style = windowObj.getComputedStyle?.(element);
      if (style && (style.display === 'none' || style.visibility === 'hidden')) return false;
    } catch {}
    return Array.from(element.getClientRects()).some((rect) => rect.width > 0 && rect.height > 0);
  }

  function getNativeChatWorkSurfaceRadios(documentObj = root.document, windowObj = root) {
    if (!documentObj?.querySelectorAll) return [];
    const groups = Array.from(
      documentObj.querySelectorAll(CHAT_WORK_SURFACE_GROUP_SELECTOR),
    ).filter((group) => isUsablyVisibleElement(group, windowObj));

    for (const group of groups) {
      const radios = Array.from(group.querySelectorAll(CHAT_WORK_SURFACE_RADIO_SELECTOR)).filter(
        (radio) => isUsablyVisibleElement(radio, windowObj),
      );
      if (radios.length !== 2) continue;
      if (radios.filter((radio) => radio.getAttribute('aria-checked') === 'true').length !== 1) {
        continue;
      }
      if (radios.filter((radio) => radio.getAttribute('aria-checked') === 'false').length !== 1) {
        continue;
      }
      return radios;
    }

    return [];
  }

  function getModelMenuButton(documentObj = root.document, windowObj = root) {
    if (!documentObj?.querySelectorAll) return null;
    const candidates = Array.from(documentObj.querySelectorAll(MODEL_MENU_BUTTON_SELECTOR));
    if (!candidates.length) return null;
    const visible = candidates.filter((candidate) => isUsablyVisibleElement(candidate, windowObj));
    return (
      visible.find((element) => element.matches(LEGACY_MODEL_MENU_BUTTON_SELECTOR)) ||
      visible.find((element) => element.matches(LEGACY_MODEL_MENU_BUTTON_CASE_SELECTOR)) ||
      visible.find((element) => element.matches(COMPOSER_MODEL_MENU_BUTTON_SELECTOR)) ||
      visible[0] ||
      candidates[0] ||
      null
    );
  }

  function getOpenModelMenuCandidates(
    documentObj = root.document,
    windowObj = root,
    trigger = null,
  ) {
    if (!documentObj?.querySelectorAll) return [];
    const triggerId = trigger?.id || '';
    return Array.from(documentObj.querySelectorAll(MODEL_MENU_SELECTOR))
      .filter((menu) => isUsablyVisibleElement(menu, windowObj))
      .filter((menu) => {
        if (triggerId && menu.getAttribute('aria-labelledby') === triggerId) return true;
        if (menu.querySelector(COMPOSER_INTELLIGENCE_MENU_CONTENT_SELECTOR)) return true;
        if (menu.querySelector(MODEL_CONFIGURE_MENU_ITEM_SELECTOR)) return true;
        return !!menu.querySelector('[data-testid^="model-switcher-"]');
      });
  }

  return Object.freeze({
    LEGACY_MODEL_MENU_BUTTON_SELECTOR,
    LEGACY_MODEL_MENU_BUTTON_CASE_SELECTOR,
    COMPOSER_MODEL_MENU_BUTTON_SELECTOR,
    MODEL_MENU_BUTTON_SELECTORS,
    MODEL_MENU_BUTTON_SELECTOR,
    MODEL_MENU_SELECTOR,
    COMPOSER_INTELLIGENCE_MENU_CONTENT_SELECTOR,
    MODEL_SUBMENU_TRIGGER_SELECTOR,
    MODEL_CONFIGURE_MENU_ITEM_SELECTOR,
    MODEL_CONFIGURE_DIALOG_SELECTOR,
    MODEL_SELECTION_LABEL_ID,
    THINKING_EFFORT_SELECTION_LABEL_ID,
    MODEL_THINKING_EFFORT_ROW_SELECTOR,
    MODEL_THINKING_EFFORT_MENU_ITEM_SELECTOR,
    MODEL_THINKING_EFFORT_ACTION_SELECTOR,
    MODEL_THINKING_EFFORT_OPTION_SELECTOR,
    PILL_ADVANCED_TOGGLE_SELECTOR,
    PILL_RESET_MENU_ITEM_SELECTOR,
    CHAT_WORK_SURFACE_GROUP_SELECTORS,
    CHAT_WORK_SURFACE_GROUP_SELECTOR,
    CHAT_WORK_SURFACE_RADIO_SELECTOR,
    normalizePillMenuLabel,
    isLikelyPillModelLabel,
    classifyPillSubmenuLabels,
    isPillAdvancedToggle,
    isPillAdvancedToggleExpanded,
    isModelSelectionViewTrigger,
    unique,
    getChatWorkSurfaceToggleSelectors,
    getChatWorkSurfaceToggleMatchGroups,
    getModelSwitcherButtonMatchGroups,
    getModelSwitcherMenuMatchGroups,
    getConfigureDialogMatchGroups,
    getConfigureModelComboboxMatchGroups,
    getConfigureModelListboxMatchGroups,
    getThinkingEffortComboboxMatchGroups,
    getThinkingEffortListboxMatchGroups,
    getModelThinkingEffortActionMatchGroups,
    getModelThinkingEffortMenuMatchGroups,
    getModelThinkingEffortStandardMatchGroups,
    getModelThinkingEffortExtendedMatchGroups,
    isUsablyVisibleElement,
    getNativeChatWorkSurfaceRadios,
    getModelMenuButton,
    getOpenModelMenuCandidates,
  });
});
